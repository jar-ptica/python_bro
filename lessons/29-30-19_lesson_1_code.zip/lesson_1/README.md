PLAN

1. interpreter

2. Base Syntax

3. built-ins (<https://docs.python.org/3.7/library/functions.html)>
    abs()
    all()
    any()
    bool()
    chr()
    dict()
    dir()
    enumerate()
    eval() - ?
    float()
    format() - ?
    getattr() - ?
    globals() - ?
    hasattr() - ?
    hash() - ?
    help()
    hex()
    id() -?
    input()
    class() - ?
    len()
    locals() - ?
    map() - ?
    max()
    min()
    open() - ?
    print()
    range()
    round()
    sorted()
    str()
    sum()
    tuple() - ?
    vars() - ?
    zip - ?

4. logic operators
    if
    else
    elif

5. Exception Handling

6. Loops
    for
    while